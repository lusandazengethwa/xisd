package com.example.artecgall;

public class User1 {
    //declaring variables
    public String fullName, age, email;

    public User1(){

    }
    public User1(String fullName, String age, String email){
        this.fullName = fullName;
        this.age = age;
        this.email = email;
    }
}
